package com.hoangquangdev.service;

public class ServiceInfo {
    public static final String Base_URL="https://static.pipezero.com/covid/";
}

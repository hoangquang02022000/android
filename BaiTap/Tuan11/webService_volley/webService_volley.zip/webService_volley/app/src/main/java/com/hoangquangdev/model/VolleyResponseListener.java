package com.hoangquangdev.model;

public interface VolleyResponseListener {
    void onErro(String mesage);
    void onResponse(ModelCommom response);
}
